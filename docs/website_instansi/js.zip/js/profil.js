/* =========================================================
   SIBAPER - MODUL PROFIL PEGAWAI
   Versi awal:
   - Penyimpanan sementara menggunakan localStorage
   - Nanti dapat diganti Google Sheet + Google Drive
========================================================= */

(function () {

    "use strict";

    const STORAGE_KEY = "sibaper_profil_data";

    const JABATAN = {
        "profil-kepala-bidang": "Kepala Bidang Pelayaran",
        "profil-bujang": "Kepala Seksi BUJANG",
        "profil-pelra": "Kepala Seksi PELRA & ASDP",
        "profil-ketua-tim": "Ketua Tim Kerja Pelabuhan",
        "profil-staf": "Staf"
    };

    let editingId = null;
    let currentPage = null;

    /* =====================================================
       STORAGE
    ===================================================== */

    function getProfiles() {

        try {

            const data = localStorage.getItem(STORAGE_KEY);

            if (!data) {
                return [];
            }

            const parsed = JSON.parse(data);

            return Array.isArray(parsed) ? parsed : [];

        } catch (error) {

            console.error("Gagal membaca data profil:", error);

            return [];

        }

    }

    function saveProfiles(data) {

        try {

            localStorage.setItem(
                STORAGE_KEY,
                JSON.stringify(data)
            );

            return true;

        } catch (error) {

            console.error("Gagal menyimpan data profil:", error);

            alert(
                "Data tidak dapat disimpan di browser. " +
                "Kemungkinan ukuran foto terlalu besar."
            );

            return false;

        }

    }

    /* =====================================================
       UTILITY
    ===================================================== */

    function escapeHTML(value) {

        if (value === null || value === undefined) {
            return "";
        }

        return String(value)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");

    }

    function generateId() {

        return (
            Date.now().toString(36) +
            Math.random().toString(36).substring(2, 8)
        );

    }

    /* =====================================================
       MODAL
    ===================================================== */

    function createModal() {

        if (document.getElementById("profilModalOverlay")) {
            return;
        }

        const modal = document.createElement("div");

        modal.id = "profilModalOverlay";

        modal.className = "profil-modal-overlay";

        modal.innerHTML = `
            <div class="profil-modal">

                <div class="profil-modal-header">

                    <h3 id="profilModalTitle">
                        Tambah Profil Pegawai
                    </h3>

                    <button
                        type="button"
                        class="profil-modal-close"
                        id="profilModalClose"
                    >
                        ×
                    </button>

                </div>

                <form
                    class="profil-form"
                    id="profilForm"
                >

                    <div class="profil-modal-body">

                        <div class="profil-form">

                            <div class="profil-form-group">

                                <label for="profilJabatan">
                                    Jabatan
                                </label>

                                <select id="profilJabatan" required>

                                    <option value="">
                                        Pilih Jabatan
                                    </option>

                                    <option value="profil-kepala-bidang">
                                        Kepala Bidang Pelayaran
                                    </option>

                                    <option value="profil-bujang">
                                        Kepala Seksi BUJANG
                                    </option>

                                    <option value="profil-pelra">
                                        Kepala Seksi PELRA & ASDP
                                    </option>

                                    <option value="profil-ketua-tim">
                                        Ketua Tim Kerja Pelabuhan
                                    </option>

                                    <option value="profil-staf">
                                        Staf
                                    </option>

                                </select>

                            </div>

                            <div class="profil-form-group">

                                <label for="profilNama">
                                    Nama Lengkap
                                </label>

                                <input
                                    type="text"
                                    id="profilNama"
                                    placeholder="Masukkan nama lengkap"
                                    required
                                >

                            </div>

                            <div class="profil-form-group">

                                <label for="profilNip">
                                    NIP
                                </label>

                                <input
                                    type="text"
                                    id="profilNip"
                                    placeholder="Masukkan NIP"
                                >

                            </div>

                            <div class="profil-form-group">

                                <label for="profilPangkat">
                                    Pangkat / Golongan
                                </label>

                                <input
                                    type="text"
                                    id="profilPangkat"
                                    placeholder="Contoh: Pembina / IV.a"
                                >

                            </div>

                            <div class="profil-form-group">

                                <label for="profilPendidikan">
                                    Pendidikan
                                </label>

                                <input
                                    type="text"
                                    id="profilPendidikan"
                                    placeholder="Contoh: S1 / S2"
                                >

                            </div>

                            <div class="profil-form-group">

                                <label for="profilTugas">
                                    Tugas dan Tanggung Jawab
                                </label>

                                <textarea
                                    id="profilTugas"
                                    placeholder="Masukkan tugas dan tanggung jawab..."
                                ></textarea>

                            </div>

                            <div class="profil-form-group">

                                <label for="profilFoto">
                                    Foto Pegawai
                                </label>

                              <input
                                    type="file"
                                    id="profilFoto"
                                    accept="image/*"
                                >

                                <span class="profil-file-help">
                                    Foto akan ditampilkan utuh dan tidak
                                    dipotong. Format JPG, JPEG, PNG, WEBP.
                                </span>

                                <img
                                    id="profilImagePreview"
                                      class="profil-image-preview"
                                    alt="Preview foto"
                                >

                            </div>

                        </div>

                    </div>

                    <div class="profil-modal-footer">

                        <button
                            type="button"
                            class="profil-cancel-button"
                            id="profilModalCancel"
                        >
                            Batal
                        </button>

                        <button
                            type="submit"
                            class="profil-save-button"
                        >
                            Simpan Profil
                        </button>

                    </div>

                </form>

            </div>
        `;

        document.body.appendChild(modal);

        bindModalEvents();

    }

    function bindModalEvents() {

        const overlay =
            document.getElementById("profilModalOverlay");

        const closeButton =
            document.getElementById("profilModalClose");

        const cancelButton =
            document.getElementById("profilModalCancel");

        const form =
            document.getElementById("profilForm");

        const fileInput =
            document.getElementById("profilFoto");

        closeButton.addEventListener(
            "click",
            closeModal
        );

        cancelButton.addEventListener(
            "click",
            closeModal
        );

        overlay.addEventListener(
            "click",
            function (event) {

                if (event.target === overlay) {
                    closeModal();
                }

            }
        );

        form.addEventListener(
            "submit",
            handleSubmit
        );

        fileInput.addEventListener(
            "change",
            handleImagePreview
        );

    }

    function openModal(pageId, profileId = null) {

        createModal();

        currentPage = pageId;

        editingId = profileId;

        const modal =
            document.getElementById("profilModalOverlay");

        const title =
            document.getElementById("profilModalTitle");

        const form =
            document.getElementById("profilForm");

        const jabatan =
            document.getElementById("profilJabatan");

        const nama =
            document.getElementById("profilNama");

        const nip =
            document.getElementById("profilNip");

        const pangkat =
            document.getElementById("profilPangkat");

        const pendidikan =
            document.getElementById("profilPendidikan");

        const tugas =
            document.getElementById("profilTugas");

        const file =
            document.getElementById("profilFoto");

        const preview =
            document.getElementById("profilImagePreview");

        form.reset();

        preview.src = "";

        preview.classList.remove("show");

        if (profileId) {

            const profiles = getProfiles();

            const profile =
                profiles.find(
                    item => item.id === profileId
                );

            if (!profile) {
                return;
            }

            title.textContent =
                "Edit Profil Pegawai";

            jabatan.value =
                profile.jabatanId;

            nama.value =
                profile.nama || "";

            nip.value =
                profile.nip || "";

            pangkat.value =
                profile.pangkat || "";

            pendidikan.value =
                profile.pendidikan || "";

            tugas.value =
                profile.tugas || "";

            if (profile.foto) {

                preview.src =
                    profile.foto;

                preview.classList.add("show");

            }

        } else {

            title.textContent =
                "Tambah Profil Pegawai";

            jabatan.value =
                pageId;

        }

        file.value = "";

        modal.classList.add("show");

    }

    function closeModal() {

        const modal =
            document.getElementById("profilModalOverlay");

        if (!modal) {
            return;
        }

        modal.classList.remove("show");

        editingId = null;

        currentPage = null;

    }

    /* =====================================================
       IMAGE
    ===================================================== */

    function handleImagePreview(event) {

        const file =
            event.target.files[0];

        const preview =
            document.getElementById("profilImagePreview");

        if (!file) {

            preview.src = "";

            preview.classList.remove("show");

            return;

        }

        if (!file.type.startsWith("image/")) {

            alert("File yang dipilih harus berupa gambar.");

            event.target.value = "";

            return;

        }

        const reader =
            new FileReader();

        reader.onload = function (e) {

            preview.src =
                e.target.result;

            preview.classList.add("show");

        };

        reader.readAsDataURL(file);

    }

    function readImageAsDataURL(file) {

        return new Promise(
            function (resolve, reject) {

                if (!file) {

                    resolve(null);

                    return;

                }

                const reader =
                    new FileReader();

                reader.onload =
                    function (event) {

                        resolve(
                            event.target.result
                        );

                    };

                reader.onerror =
                    function () {

                        reject(
                            new Error(
                                "Gagal membaca foto."
                            )
                        );

                    };

                reader.readAsDataURL(file);

            }
        );

    }

    /* =====================================================
       SUBMIT
    ===================================================== */

    async function handleSubmit(event) {

        event.preventDefault();

        const jabatanId =
            document.getElementById(
                "profilJabatan"
            ).value;

        const nama =
            document.getElementById(
                "profilNama"
            ).value.trim();

        const nip =
            document.getElementById(
                "profilNip"
            ).value.trim();

        const pangkat =
            document.getElementById(
                "profilPangkat"
            ).value.trim();

        const pendidikan =
            document.getElementById(
                "profilPendidikan"
            ).value.trim();

        const tugas =
            document.getElementById(
                "profilTugas"
            ).value.trim();

        const file =
            document.getElementById(
                "profilFoto"
            ).files[0];

        if (!jabatanId) {

            alert("Silakan pilih jabatan.");

            return;

        }

        if (!nama) {

            alert("Nama lengkap wajib diisi.");

            return;

        }

        const profiles =
            getProfiles();

        if (editingId) {

            const index =
                profiles.findIndex(
                    item => item.id === editingId
                );

            if (index === -1) {

                alert(
                    "Data profil tidak ditemukan."
                );

                return;

            }

            let foto =
                profiles[index].foto || "";

            if (file) {

                foto =
                    await readImageAsDataURL(file);

            }

            profiles[index] = {

                ...profiles[index],

                jabatanId,

                jabatan:
                    JABATAN[jabatanId],

                nama,

                nip,

                pangkat,

                pendidikan,

                tugas,

                foto,

                updatedAt:
                    new Date().toISOString()

            };

        } else {

            let foto = "";

            if (file) {

                foto =
                    await readImageAsDataURL(file);

            }

            profiles.push({

                id:
                    generateId(),

                jabatanId,

                jabatan:
                    JABATAN[jabatanId],

                nama,

                nip,

                pangkat,

                pendidikan,

                tugas,

                foto,

                createdAt:
                    new Date().toISOString(),

                updatedAt:
                    new Date().toISOString()

            });

        }

        const success =
            saveProfiles(profiles);

        if (!success) {
            return;
        }

        closeModal();

        renderAllProfilePages();

    }

    /* =====================================================
       RENDER
    ===================================================== */

    function renderAllProfilePages() {

        Object.keys(JABATAN)
            .forEach(renderProfilePage);

    }

    function renderProfilePage(pageId) {

        const page =
            document.querySelector(
                `[data-content="${pageId}"]`
            );

        if (!page) {
            return;
        }

        const profiles =
            getProfiles().filter(
                profile =>
                    profile.jabatanId === pageId
            );

        let grid =
            page.querySelector(
                ".profil-card-grid"
            );

        if (!grid) {

            grid =
                document.createElement("div");

            grid.className =
                "profil-card-grid";

            page.appendChild(grid);

        }

        const heading =
            page.querySelector(
                ".content-heading"
            );

        if (heading) {

            const oldToolbar =
                page.querySelector(
                    ".profil-toolbar"
                );

            if (oldToolbar) {
                oldToolbar.remove();
            }

            const toolbar =
                document.createElement("div");

            toolbar.className =
                "profil-toolbar";

            toolbar.innerHTML = `

                <div class="profil-toolbar-info">

                    <small>
                        Data pegawai yang terdaftar
                    </small>

                    <span class="profil-count">
                        ${profiles.length}
                        ${profiles.length === 1 ? "pegawai" : "pegawai"}
                    </span>

                </div>

                <button
                    type="button"
                    class="profil-add-button"
                    data-profile-add="${pageId}"
                >
                    <span>＋</span>
                    <span>Tambah Profil</span>
                </button>

            `;

            heading.after(toolbar);

        }

        const emptyContent =
            page.querySelector(
                ".empty-content"
            );

        if (emptyContent) {
            emptyContent.style.display =
                "none";
        }

        grid.innerHTML = "";

        if (profiles.length === 0) {

            grid.innerHTML = `

                <div class="profil-empty">

                    <div class="profil-empty-icon">
                        👤
                    </div>

                    <h3>
                        Belum ada data profil
                    </h3>

                    <p>
                        Klik "Tambah Profil" untuk
                        menambahkan data pegawai.
                    </p>

                </div>

            `;

            return;

        }

        profiles.forEach(
            profile => {

                grid.appendChild(
                    createProfileCard(profile)
                );

            }
        );

    }

    function createProfileCard(profile) {

        const card =
            document.createElement("article");

        card.className =
            "profil-card";

        const fotoHTML =
            profile.foto

                ? `
                    <img
                        class="profil-photo"
                        src="${profile.foto}"
                        alt="Foto ${escapeHTML(profile.nama)}"
                    >
                `

                : `
                    <div class="profil-photo-placeholder">
                        👤
                    </div>
                `;

        card.innerHTML = `

            <div class="profil-photo-wrapper">

                ${fotoHTML}

            </div>

            <div class="profil-card-body">

                <span class="profil-position">
                    ${escapeHTML(profile.jabatan)}
                </span>

                <h3 class="profil-name">
                    ${escapeHTML(profile.nama)}
                </h3>

                <div class="profil-details">

                    <div class="profil-detail-row">

                        <span class="profil-detail-label">
                            NIP
                        </span>

                        <span class="profil-detail-value">
                            ${escapeHTML(profile.nip) || "-"}
                        </span>

                    </div>

                    <div class="profil-detail-row">

                        <span class="profil-detail-label">
                            Pangkat / Golongan
                        </span>

                        <span class="profil-detail-value">
                            ${escapeHTML(profile.pangkat) || "-"}
                        </span>

                    </div>

                    <div class="profil-detail-row">

                        <span class="profil-detail-label">
                            Pendidikan
                        </span>

                        <span class="profil-detail-value">
                            ${escapeHTML(profile.pendidikan) || "-"}
                        </span>

                    </div>

                </div>

                <div class="profil-task">

                    <div class="profil-task-title">
                        Tugas dan Tanggung Jawab
                    </div>

                    <div class="profil-task-text">
                        ${escapeHTML(profile.tugas) || "-"}
                    </div>

                </div>

                <div class="profil-actions">

                    <button
                        type="button"
                        class="profil-action profil-edit-button"
                        data-profile-edit="${profile.id}"
                    >
                        ✎ Edit
                    </button>

                    <button
                        type="button"
                        class="profil-action profil-delete-button"
                        data-profile-delete="${profile.id}"
                    >
                        🗑 Hapus
                    </button>

                </div>

            </div>

        `;

        return card;

    }

    /* =====================================================
       ACTION
    ===================================================== */

    function handleProfileAction(event) {

        const addButton =
            event.target.closest(
                "[data-profile-add]"
            );

        if (addButton) {

            const pageId =
                addButton.dataset.profileAdd;

            openModal(pageId);

            return;

        }

        const editButton =
            event.target.closest(
                "[data-profile-edit]"
            );

        if (editButton) {

            const id =
                editButton.dataset.profileEdit;

            const profiles =
                getProfiles();

            const profile =
                profiles.find(
                    item => item.id === id
                );

            if (!profile) {
                return;
            }

            openModal(
                profile.jabatanId,
                id
            );

            return;

        }

        const deleteButton =
            event.target.closest(
                "[data-profile-delete]"
            );

        if (deleteButton) {

            const id =
                deleteButton.dataset.profileDelete;

            deleteProfile(id);

        }

    }

    function deleteProfile(id) {

        const profiles =
            getProfiles();

        const profile =
            profiles.find(
                item => item.id === id
            );

        if (!profile) {
            return;
        }

        const confirmed =
            confirm(
                `Hapus profil "${profile.nama}"?`
            );

        if (!confirmed) {
            return;
        }

        const newProfiles =
            profiles.filter(
                item => item.id !== id
            );

        saveProfiles(newProfiles);

        renderAllProfilePages();

    }

    /* =====================================================
       INITIALIZATION
    ===================================================== */

    function initialize() {

        createModal();

        renderAllProfilePages();

        document.addEventListener(
            "click",
            handleProfileAction
        );

        console.log(
            "SIBAPER Profil berhasil dijalankan."
        );

    }

    if (
        document.readyState === "loading"
    ) {

        document.addEventListener(
            "DOMContentLoaded",
            initialize
        );

    } else {

        initialize();

    }

})();