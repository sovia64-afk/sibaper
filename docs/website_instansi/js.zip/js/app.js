/* =========================================================
   SIBAPER - APPLICATION + MODUL DATA
   Semua fungsi utama dalam SATU FILE
========================================================= */


/* =========================================================
   PAGE INFORMATION
========================================================= */

const pageInformation = {

    "beranda": {
        title: "Beranda",
        description:
            "Selamat datang di Sistem Informasi Bidang Pelayaran"
    },

    "profil-kepala-bidang": {
        title: "Kepala Bidang Pelayaran",
        description:
            "Data profil Kepala Bidang Pelayaran"
    },

    "profil-bujang": {
        title: "Kepala Seksi BUJANG",
        description:
            "Data profil Kepala Seksi BUJANG"
    },

    "profil-pelra": {
        title: "Kepala Seksi PELRA & ASDP",
        description:
            "Data profil Kepala Seksi PELRA & ASDP"
    },

    "profil-ketua-tim": {
        title: "Ketua Tim Kerja Pelabuhan",
        description:
            "Data profil Ketua Tim Kerja Pelabuhan"
    },

    "profil-staf": {
        title: "Staf",
        description:
            "Data staf Bidang Pelayaran"
    },

    "struktur-2025": {
        title: "Struktur Organisasi 2025",
        description:
            "Struktur organisasi Bidang Pelayaran tahun 2025"
    },

    "struktur-2026": {
        title: "Struktur Organisasi 2026",
        description:
            "Struktur organisasi Bidang Pelayaran tahun 2026"
    },

    "database-pelra": {
        title: "Database PELRA ASDP",
        description:
            "Data bidang PELRA dan ASDP"
    },

    "database-bujang": {
        title: "Database BUJANG",
        description:
            "Data bidang BUJANG"
    },

    "perencanaan-2025": {
        title: "Perencanaan 2025",
        description:
            "Kebutuhan SAKIP"
    },

    "perencanaan-2026": {
        title: "Perencanaan 2026",
        description:
            "Kebutuhan SIMBANGDA"
    },

    "perencanaan-2027": {
        title: "Perencanaan 2027",
        description:
            "Data perencanaan tahun 2027"
    },

    "realisasi-anggaran": {
        title: "Realisasi Anggaran Bidang",
        description:
            "Realisasi rinci keseluruhan anggaran bidang"
    },

    "realisasi-pelra": {
        title: "Seksi PELRA & ASDP",
        description:
            "Pengawasan SPM"
    },

    "realisasi-bujang": {
        title: "Seksi BUJANG",
        description:
            "Data realisasi Seksi BUJANG"
    },

    "realisasi-rekomendasi-teknis": {
        title: "Rekomendasi Teknis",
        description:
            "Rekomendasi teknis Seksi BUJANG"
    },

    "realisasi-rekomendasi-smu": {
        title: "Rekomendasi SMU",
        description:
            "Rekomendasi SMU Seksi BUJANG"
    },

    "realisasi-pengawasan-usaha": {
        title: "Pengawasan Badan Usaha",
        description:
            "Data pelaksanaan pengawasan badan usaha"
    },

    "laporan-tahunan": {
        title: "Laporan Tahunan",
        description:
            "Laporan kegiatan tahunan seluruh sub kegiatan"
    },

    "laporan-badan-usaha": {
        title: "Laporan Badan Usaha",
        description:
            "Laporan bulanan JPT dan PBM"
    },

    "laporan-analisis": {
        title: "Analisis & Grafik",
        description:
            "Analisis data dan visualisasi Bidang Pelayaran"
    },

    "kinerja-evaluasi": {
        title: "Evaluasi",
        description:
            "Evaluasi kinerja pegawai Bidang Pelayaran"
    },

    "kinerja-penilaian": {
        title: "Penilaian",
        description:
            "Penilaian kinerja pegawai Bidang Pelayaran"
    },

    "galeri-foto": {
        title: "Foto",
        description:
            "Dokumentasi foto kegiatan Bidang Pelayaran"
    },

    "galeri-video": {
        title: "Video",
        description:
            "Dokumentasi video kegiatan Bidang Pelayaran"
    },

    "galeri-regulasi": {
        title: "Regulasi",
        description:
            "Peraturan terkait pelayaran"
    }

};


/* =========================================================
   SHOW PAGE
========================================================= */

function showPage(pageName) {

    if (!pageName) {
        pageName = "beranda";
    }


    document
        .querySelectorAll(".sibaper-page")
        .forEach(function(page) {

            page.classList.remove("active");

        });


    const selectedPage =
        document.querySelector(
            `.sibaper-page[data-content="${pageName}"]`
        );


    if (selectedPage) {

        selectedPage.classList.add("active");

    }


    const pageTitle =
        document.getElementById("pageTitle");

    const pageDescription =
        document.getElementById("pageDescription");


    const information =
        pageInformation[pageName];


    if (
        information &&
        pageTitle &&
        pageDescription
    ) {

        pageTitle.textContent =
            information.title;

        pageDescription.textContent =
            information.description;

    }


    document
        .querySelectorAll(
            ".sibaper-menu-item[data-page]"
        )
        .forEach(function(item) {

            item.classList.remove("active");

        });


    document
        .querySelectorAll(
            ".sibaper-submenu button"
        )
        .forEach(function(item) {

            item.classList.remove("active");

        });


    const selectedSubmenu =
        document.querySelector(
            `.sibaper-submenu button[data-page="${pageName}"]`
        );


    if (selectedSubmenu) {

        selectedSubmenu.classList.add("active");


        const parentGroup =
            selectedSubmenu.closest(
                ".sibaper-menu-group"
            );


        if (parentGroup) {

            parentGroup.classList.add("open");


            const parentButton =
                parentGroup.querySelector(
                    ".sibaper-parent"
                );


            if (parentButton) {

                parentButton.classList.add("active");

            }

        }

    }


    const selectedMenu =
        document.querySelector(
            `.sibaper-menu-item[data-page="${pageName}"]`
        );


    if (selectedMenu) {

        selectedMenu.classList.add("active");

    }


    const main =
        document.querySelector(".sibaper-main");


    if (main) {

        main.scrollTop = 0;

    }


    document.dispatchEvent(
        new CustomEvent(
            "sibaperPageChanged",
            {
                detail: {
                    page: pageName
                }
            }
        )
    );

}


/* =========================================================
   INITIALIZATION APP
========================================================= */

function initializeSibaperApp() {


    document
        .querySelectorAll(
            ".sibaper-menu-item[data-page]"
        )
        .forEach(function(item) {

            item.addEventListener(
                "click",
                function() {

                    showPage(
                        this.dataset.page
                    );

                }
            );

        });


    document
        .querySelectorAll(
            ".sibaper-submenu button[data-page]"
        )
        .forEach(function(item) {

            item.addEventListener(
                "click",
                function() {

                    showPage(
                        this.dataset.page
                    );

                }
            );

        });


    document
        .querySelectorAll(
            ".sibaper-parent"
        )
        .forEach(function(parent) {

            parent.addEventListener(
                "click",
                function() {

                    const group =
                        this.closest(
                            ".sibaper-menu-group"
                        );


                    if (!group) {
                        return;
                    }


                    group.classList.toggle(
                        "open"
                    );

                }
            );

        });


    document
        .querySelectorAll("[data-page]")
        .forEach(function(element) {

            if (
                element.matches(
                    ".sibaper-menu-item, .sibaper-submenu button"
                )
            ) {

                return;

            }


            element.addEventListener(
                "click",
                function() {

                    if (this.dataset.page) {

                        showPage(
                            this.dataset.page
                        );

                    }

                }
            );

        });


    const logoutButton =
        document.getElementById(
            "logoutButton"
        );


    if (logoutButton) {

        logoutButton.addEventListener(
            "click",
            function() {

                if (
                    confirm(
                        "Apakah Anda yakin ingin keluar dari SIBAPER?"
                    )
                ) {

                    window.location.href =
                        "login.html";

                }

            }
        );

    }


    const mobileButton =
        document.getElementById(
            "mobileMenuButton"
        );


    const sidebar =
        document.querySelector(
            ".sibaper-sidebar"
        );


    if (
        mobileButton &&
        sidebar
    ) {

        mobileButton.addEventListener(
            "click",
            function() {

                sidebar.classList.toggle(
                    "mobile-open"
                );

            }
        );

    }


    document
        .querySelectorAll(
            ".sibaper-submenu button"
        )
        .forEach(function(item) {

            item.addEventListener(
                "click",
                function() {

                    if (
                        window.innerWidth <= 900 &&
                        sidebar
                    ) {

                        sidebar.classList.remove(
                            "mobile-open"
                        );

                    }

                }
            );

        });


    showPage("beranda");


    console.log(
        "SIBAPER Application berhasil dijalankan."
    );

}


/* =========================================================
   MODUL DATA SIBAPER
========================================================= */

(function () {

    "use strict";


    const PREFIX =
        "sibaper_data_";


    /* =====================================================
       KONFIGURASI SEMUA DATA
    ===================================================== */

    const CONFIG = {


        /* ================= STRUCTURE ================= */

        "struktur-2025": {

            title:
                "Upload Struktur Organisasi 2025",

            fields: [

                [
                    "judul",
                    "Judul / Keterangan",
                    "text",
                    true
                ],

                [
                    "file",
                    "File Struktur",
                    "file",
                    true
                ]

            ]

        },


        "struktur-2026": {

            title:
                "Upload Struktur Organisasi 2026",

            fields: [

                [
                    "judul",
                    "Judul / Keterangan",
                    "text",
                    true
                ],

                [
                    "file",
                    "File Struktur",
                    "file",
                    true
                ]

            ]

        },


        /* ================= DATABASE ================= */

        "database-pelra": {

            title:
                "Tambah Data PELRA ASDP",

            fields: [

                [
                    "namaPerusahaan",
                    "Nama Perusahaan",
                    "text",
                    true
                ],

                [
                    "jenisPerusahaan",
                    "Jenis Perusahaan",
                    "text",
                    false
                ],

                [
                    "pimpinan",
                    "Pimpinan Perusahaan",
                    "text",
                    false
                ],

                [
                    "nomorIzin",
                    "Nomor Izin / Dokumen",
                    "text",
                    false
                ],

                [
                    "status",
                    "Status",
                    "text",
                    false
                ],

                [
                    "keterangan",
                    "Keterangan",
                    "textarea",
                    false
                ]

            ]

        },


        "database-bujang": {

            title:
                "Tambah Data BUJANG",

            fields: [

                [
                    "namaPerusahaan",
                    "Nama Perusahaan",
                    "text",
                    true
                ],

                [
                    "jenisPerusahaan",
                    "Jenis Perusahaan",
                    "text",
                    false
                ],

                [
                    "pimpinan",
                    "Pimpinan Perusahaan",
                    "text",
                    false
                ],

                [
                    "nomorIzin",
                    "Nomor Izin / Dokumen",
                    "text",
                    false
                ],

                [
                    "status",
                    "Status",
                    "text",
                    false
                ],

                [
                    "keterangan",
                    "Keterangan",
                    "textarea",
                    false
                ]

            ]

        },


        /* ================= PERENCANAAN ================= */

        "perencanaan-2025": {

            title:
                "Tambah Dokumen Perencanaan 2025",

            fields: [

                [
                    "program",
                    "Program",
                    "text",
                    false
                ],

                [
                    "kegiatan",
                    "Kegiatan",
                    "text",
                    false
                ],

                [
                    "subKegiatan",
                    "Sub Kegiatan PK",
                    "text",
                    false
                ],

                [
                    "rencanaAksi",
                    "Rencana Aksi",
                    "textarea",
                    false
                ],

                [
                    "realisasiPk",
                    "Realisasi PK",
                    "textarea",
                    false
                ],

                [
                    "realisasiRencanaAksi",
                    "Realisasi Rencana Aksi",
                    "textarea",
                    false
                ],

                [
                    "dokumen",
                    "Dokumen",
                    "file",
                    false
                ]

            ]

        },


        "perencanaan-2026": {

            title:
                "Tambah Dokumen Perencanaan 2026",

            fields: [

                [
                    "jenisDokumen",
                    "Jenis Dokumen",
                    "select",
                    true,
                    [
                        "SK",
                        "NOTULEN",
                        "KWITANSI",
                        "DLL"
                    ]
                ],

                [
                    "judul",
                    "Judul Dokumen",
                    "text",
                    true
                ],

                [
                    "keterangan",
                    "Keterangan",
                    "textarea",
                    false
                ],

                [
                    "dokumen",
                    "File Dokumen",
                    "file",
                    false
                ]

            ]

        },


        "perencanaan-2027": {

            title:
                "Tambah Dokumen Perencanaan 2027",

            fields: [

                [
                    "judul",
                    "Judul / Kegiatan",
                    "text",
                    true
                ],

                [
                    "keterangan",
                    "Keterangan",
                    "textarea",
                    false
                ],

                [
                    "dokumen",
                    "File Dokumen",
                    "file",
                    false
                ]

            ]

        },


        /* ================= REALISASI ================= */

        "realisasi-anggaran": {

            title:
                "Tambah Realisasi Anggaran",

            fields: [

                [
                    "kegiatan",
                    "Kegiatan",
                    "text",
                    true
                ],

                [
                    "pagu",
                    "Pagu Anggaran",
                    "number",
                    false
                ],

                [
                    "realisasi",
                    "Realisasi",
                    "number",
                    false
                ],

                [
                    "persentase",
                    "Persentase (%)",
                    "number",
                    false
                ],

                [
                    "keterangan",
                    "Keterangan",
                    "textarea",
                    false
                ],

                [
                    "dokumen",
                    "Dokumen Pendukung",
                    "file",
                    false
                ]

            ]

        },


        "realisasi-pelra": {

            title:
                "Tambah Pengawasan SPM",

            fields: [

                [
                    "tanggal",
                    "Tanggal",
                    "date",
                    true
                ],

                [
                    "perusahaan",
                    "Perusahaan",
                    "text",
                    true
                ],

                [
                    "jenis",
                    "Jenis / Kegiatan",
                    "text",
                    false
                ],

                [
                    "lokasi",
                    "Lokasi",
                    "text",
                    false
                ],

                [
                    "hasil",
                    "Hasil Pengawasan",
                    "textarea",
                    false
                ],

                [
                    "dokumen",
                    "Dokumen Pendukung",
                    "file",
                    false
                ]

            ]

        },


        "realisasi-rekomendasi-teknis": {

            title:
                "Tambah Rekomendasi Teknis",

            fields: [

                [
                    "nomorSurat",
                    "Nomor Surat",
                    "text",
                    true
                ],

                [
                    "tanggal",
                    "Tanggal",
                    "date",
                    true
                ],

                [
                    "perihal",
                    "Perihal",
                    "text",
                    false
                ],

                [
                    "namaPerusahaan",
                    "Nama Perusahaan",
                    "text",
                    true
                ],

                [
                    "pimpinan",
                    "Pimpinan Perusahaan",
                    "text",
                    false
                ],

                [
                    "jenisPerusahaan",
                    "Jenis Perusahaan",
                    "text",
                    false
                ],

                [
                    "dokumen",
                    "File PDF Rekomendasi",
                    "file",
                    false
                ]

            ]

        },


        "realisasi-rekomendasi-smu": {

            title:
                "Tambah Rekomendasi SMU",

            fields: [

                [
                    "nomorSurat",
                    "Nomor Surat",
                    "text",
                    true
                ],

                [
                    "tanggal",
                    "Tanggal",
                    "date",
                    true
                ],

                [
                    "perihal",
                    "Perihal",
                    "text",
                    false
                ],

                [
                    "namaPerusahaan",
                    "Nama Perusahaan",
                    "text",
                    true
                ],

                [
                    "pimpinan",
                    "Pimpinan Perusahaan",
                    "text",
                    false
                ],

                [
                    "jenisPerusahaan",
                    "Jenis Perusahaan",
                    "text",
                    false
                ],

                [
                    "dokumen",
                    "File PDF Rekomendasi",
                    "file",
                    false
                ]

            ]

        },


        "realisasi-pengawasan-usaha": {

            title:
                "Tambah Pengawasan Badan Usaha",

            fields: [

                [
                    "tanggal",
                    "Tanggal",
                    "date",
                    true
                ],

                [
                    "perusahaan",
                    "Perusahaan",
                    "text",
                    true
                ],

                [
                    "jenis",
                    "Jenis",
                    "text",
                    false
                ],

                [
                    "lokasi",
                    "Lokasi",
                    "text",
                    false
                ],

                [
                    "pimpinan",
                    "Pimpinan",
                    "text",
                    false
                ],

                [
                    "hasil",
                    "Hasil Pengawasan",
                    "textarea",
                    false
                ],

                [
                    "dokumen",
                    "Dokumen",
                    "file",
                    false
                ]

            ]

        },


        /* ================= LAPORAN ================= */

        "laporan-tahunan": {

            title:
                "Upload Laporan Tahunan",

            fields: [

                [
                    "judul",
                    "Judul Laporan",
                    "text",
                    true
                ],

                [
                    "tahun",
                    "Tahun",
                    "number",
                    false
                ],

                [
                    "keterangan",
                    "Keterangan",
                    "textarea",
                    false
                ],

                [
                    "dokumen",
                    "File Laporan",
                    "file",
                    true
                ]

            ]

        },


        "laporan-badan-usaha": {

            title:
                "Tambah Laporan Badan Usaha",

            fields: [

                [
                    "namaPerusahaan",
                    "Nama Perusahaan",
                    "text",
                    true
                ],

                [
                    "jenisPerusahaan",
                    "Jenis Perusahaan",
                    "text",
                    false
                ],

                [
                    "pimpinan",
                    "Pimpinan Perusahaan",
                    "text",
                    false
                ],

                [
                    "muatan",
                    "Muatan Ton / M³",
                    "number",
                    false
                ],

                [
                    "jenisMuatan",
                    "Jenis Muatan",
                    "text",
                    false
                ],

                [
                    "bulan",
                    "Bulan",
                    "text",
                    false
                ],

                [
                    "asal",
                    "Asal Lokasi",
                    "text",
                    false
                ],

                [
                    "tujuan",
                    "Tujuan",
                    "text",
                    false
                ],

                [
                    "kendaraan",
                    "Kendaraan yang Digunakan",
                    "text",
                    false
                ]

            ]

        },


        /* ================= GALERI ================= */

        "galeri-foto": {

            title:
                "Tambah Foto",

            fields: [

                [
                    "judul",
                    "Judul Foto",
                    "text",
                    true
                ],

                [
                    "tanggal",
                    "Tanggal",
                    "date",
                    false
                ],

                [
                    "keterangan",
                    "Keterangan",
                    "textarea",
                    false
                ],

                [
                    "file",
                    "Foto",
                    "file",
                    true
                ]

            ]

        },


        "galeri-video": {

            title:
                "Tambah Video",

            fields: [

                [
                    "judul",
                    "Judul Video",
                    "text",
                    true
                ],

                [
                    "tanggal",
                    "Tanggal",
                    "date",
                    false
                ],

                [
                    "url",
                    "URL Video YouTube / Video",
                    "url",
                    false
                ],

                [
                    "keterangan",
                    "Keterangan",
                    "textarea",
                    false
                ]

            ]

        },


        "galeri-regulasi": {

            title:
                "Tambah Regulasi",

            fields: [

                [
                    "judul",
                    "Judul Regulasi",
                    "text",
                    true
                ],

                [
                    "nomor",
                    "Nomor Regulasi",
                    "text",
                    false
                ],

                [
                    "tahun",
                    "Tahun",
                    "number",
                    false
                ],

                [
                    "keterangan",
                    "Keterangan",
                    "textarea",
                    false
                ],

                [
                    "dokumen",
                    "File Regulasi",
                    "file",
                    false
                ]

            ]

        }

    };


    /* =====================================================
       STORAGE
    ===================================================== */

    function storageKey(page) {

        return PREFIX + page;

    }


    function read(page) {

        try {

            const raw =
                localStorage.getItem(
                    storageKey(page)
                );


            if (!raw) {
                return [];
            }


            const data =
                JSON.parse(raw);


            return Array.isArray(data)
                ? data
                : [];

        } catch (error) {

            console.error(
                "Gagal membaca data:",
                error
            );

            return [];

        }

    }


    function write(page, data) {

        try {

            localStorage.setItem(
                storageKey(page),
                JSON.stringify(data)
            );

            return true;

        } catch (error) {

            console.error(
                "Gagal menyimpan data:",
                error
            );


            alert(
                "Data gagal disimpan. Kemungkinan ukuran file terlalu besar untuk localStorage browser."
            );


            return false;

        }

    }


    function createId() {

        return (
            Date.now().toString(36) +
            Math.random()
                .toString(36)
                .substring(2, 9)
        );

    }


    function escapeHTML(value) {

        if (
            value === null ||
            value === undefined
        ) {

            return "";

        }


        return String(value)

            .replace(
                /&/g,
                "&amp;"
            )

            .replace(
                /</g,
                "&lt;"
            )

            .replace(
                />/g,
                "&gt;"
            )

            .replace(
                /"/g,
                "&quot;"
            )

            .replace(
                /'/g,
                "&#039;"
            );

    }


    function fileToDataURL(file) {

        return new Promise(
            function(resolve, reject) {

                const reader =
                    new FileReader();


                reader.onload =
                    function() {

                        resolve(
                            reader.result
                        );

                    };


                reader.onerror =
                    reject;


                reader.readAsDataURL(
                    file
                );

            }
        );

    }


    /* =====================================================
       MODAL
    ===================================================== */

    function buildModal() {

        if (
            document.getElementById(
                "sibaperDataModal"
            )
        ) {

            return;

        }


        const modal =
            document.createElement(
                "div"
            );


        modal.id =
            "sibaperDataModal";


        modal.className =
            "sibaper-data-modal";


        modal.innerHTML = `

            <div class="sibaper-data-modal-box">

                <div class="sibaper-data-modal-header">

                    <div>

                        <span>
                            SIBAPER
                        </span>

                        <h2
                            id="sibaperDataModalTitle"
                        >
                            Tambah Data
                        </h2>

                    </div>


                    <button
                        type="button"
                        id="sibaperDataClose"
                        class="sibaper-data-close"
                    >
                        ×
                    </button>

                </div>


                <form
                    id="sibaperDataForm"
                >

                    <input
                        type="hidden"
                        id="sibaperDataPage"
                    >

                    <input
                        type="hidden"
                        id="sibaperDataId"
                    >


                    <div
                        id="sibaperDataFields"
                        class="sibaper-data-fields"
                    >
                    </div>


                    <div
                        class="sibaper-data-footer"
                    >

                        <button
                            type="button"
                            class="sibaper-data-cancel"
                            id="sibaperDataCancel"
                        >
                            Batal
                        </button>


                        <button
                            type="submit"
                            class="sibaper-data-save"
                        >
                            Simpan Data
                        </button>

                    </div>

                </form>

            </div>

        `;


        document.body.appendChild(
            modal
        );


        document
            .getElementById(
                "sibaperDataClose"
            )
            .addEventListener(
                "click",
                closeModal
            );


        document
            .getElementById(
                "sibaperDataCancel"
            )
            .addEventListener(
                "click",
                closeModal
            );


        modal.addEventListener(
            "click",
            function(event) {

                if (
                    event.target === modal
                ) {

                    closeModal();

                }

            }
        );


        document
            .getElementById(
                "sibaperDataForm"
            )
            .addEventListener(
                "submit",
                saveData
            );

    }


    /* =====================================================
       RENDER FORM
    ===================================================== */

    function renderFields(
        page,
        existing
    ) {

        const cfg =
            CONFIG[page];


        const box =
            document.getElementById(
                "sibaperDataFields"
            );


        box.innerHTML = "";


        cfg.fields.forEach(
            function(field) {

                const name =
                    field[0];

                const label =
                    field[1];

                const type =
                    field[2];

                const required =
                    field[3];

                const options =
                    field[4];


                const group =
                    document.createElement(
                        "div"
                    );


                group.className =
                    "sibaper-data-field";


                const value =
                    existing[name] || "";


                let inputHTML =
                    "";


                if (
                    type === "textarea"
                ) {

                    inputHTML = `

                        <textarea
                            id="data_${name}"
                            ${
                                required
                                    ? "required"
                                    : ""
                            }
                            placeholder="${escapeHTML(label)}"
                        >${escapeHTML(value)}</textarea>

                    `;

                }

                else if (
                    type === "select"
                ) {

                    inputHTML = `

                        <select
                            id="data_${name}"
                            ${
                                required
                                    ? "required"
                                    : ""
                            }
                        >

                            <option value="">
                                Pilih ${escapeHTML(label)}
                            </option>

                            ${
                                options
                                    .map(
                                        function(option) {

                                            return `

                                                <option
                                                    value="${escapeHTML(option)}"
                                                    ${
                                                        value === option
                                                            ? "selected"
                                                            : ""
                                                    }
                                                >
                                                    ${escapeHTML(option)}
                                                </option>

                                            `;

                                        }
                                    )
                                    .join("")
                            }

                        </select>

                    `;

                }

                else if (
                    type === "file"
                ) {

                    inputHTML = `

                        <input
                            id="data_${name}"
                            type="file"
                            ${
                                required &&
                                !existing[name]
                                    ? "required"
                                    : ""
                            }
                        >

                        ${
                            existing[name]
                                ? `
                                    <small>
                                        File tersimpan.
                                        Pilih file baru jika
                                        ingin mengganti.
                                    </small>
                                `
                                : ""
                        }

                    `;

                }

                else {

                    inputHTML = `

                        <input
                            id="data_${name}"
                            type="${type}"
                            value="${escapeHTML(value)}"
                            ${
                                required
                                    ? "required"
                                    : ""
                            }
                            placeholder="${escapeHTML(label)}"
                        >

                    `;

                }


                group.innerHTML = `

                    <label>

                        ${escapeHTML(label)}

                        ${
                            required
                                ? " *"
                                : ""
                        }

                    </label>

                    ${inputHTML}

                `;


                box.appendChild(
                    group
                );

            }
        );

    }


    /* =====================================================
       OPEN MODAL
    ===================================================== */

    function openDataModal(
        page,
        editId
    ) {

        const cfg =
            CONFIG[page];


        if (!cfg) {
            return;
        }


        buildModal();


        const data =
            read(page);


        const existing =
            data.find(
                function(item) {

                    return item.id === editId;

                }
            ) || {};


        document
            .getElementById(
                "sibaperDataPage"
            )
            .value =
            page;


        document
            .getElementById(
                "sibaperDataId"
            )
            .value =
            editId || "";


        document
            .getElementById(
                "sibaperDataModalTitle"
            )
            .textContent =
            editId
                ? "Edit Data"
                : cfg.title;


        renderFields(
            page,
            existing
        );


        document
            .getElementById(
                "sibaperDataModal"
            )
            .classList.add(
                "show"
            );

    }


    function closeModal() {

        const modal =
            document.getElementById(
                "sibaperDataModal"
            );


        if (modal) {

            modal.classList.remove(
                "show"
            );

        }

    }


    /* =====================================================
       SAVE DATA
    ===================================================== */

    async function saveData(
        event
    ) {

        event.preventDefault();


        const page =
            document.getElementById(
                "sibaperDataPage"
            ).value;


        const editId =
            document.getElementById(
                "sibaperDataId"
            ).value;


        const cfg =
            CONFIG[page];


        if (!cfg) {
            return;
        }


        const data =
            read(page);


        const existing =
            data.find(
                function(item) {

                    return item.id === editId;

                }
            ) || {};


        const record = {

            ...existing,

            id:
                editId ||
                createId(),

            updatedAt:
                new Date()
                    .toISOString()

        };


        for (
            const field
            of cfg.fields
        ) {

            const name =
                field[0];

            const type =
                field[2];


            const input =
                document.getElementById(
                    "data_" + name
                );


            if (!input) {
                continue;
            }


            if (
                type === "file"
            ) {

                if (
                    input.files &&
                    input.files[0]
                ) {

                    try {

                        record[name] =
                            await fileToDataURL(
                                input.files[0]
                            );


                        record[name + "Name"] =
                            input.files[0].name;


                        record[name + "Type"] =
                            input.files[0].type;

                    } catch (error) {

                        console.error(
                            "Gagal membaca file:",
                            error
                        );


                        alert(
                            "File gagal dibaca."
                        );


                        return;

                    }

                }

            }

            else {

                record[name] =
                    input.value.trim();

            }

        }


        if (editId) {

            const index =
                data.findIndex(
                    function(item) {

                        return item.id === editId;

                    }
                );


            if (index >= 0) {

                data[index] =
                    record;

            }

        }

        else {

            record.createdAt =
                new Date()
                    .toISOString();


            data.push(
                record
            );

        }


        if (
            !write(
                page,
                data
            )
        ) {

            return;

        }


        closeModal();


        renderDataPage(
            page
        );


        alert(
            editId
                ? "Data berhasil diperbarui."
                : "Data berhasil disimpan."
        );

    }


    /* =====================================================
       FILE
    ===================================================== */

    function getFileName(
        record
    ) {

        return (
            record.fileName ||
            record.dokumenName ||
            "Lihat file"
        );

    }


    function getFileButton(
        record
    ) {

        const src =
            record.file ||
            record.dokumen;


        if (!src) {
            return "";
        }


        return `

            <a
                class="sibaper-file-link"
                href="${src}"
                target="_blank"
                rel="noopener"
            >

                📎
                ${escapeHTML(
                    getFileName(record)
                )}

            </a>

        `;

    }


    /* =====================================================
       JUDUL CARD
    ===================================================== */

    function recordTitle(
        page,
        record
    ) {

        return (

            record.judul ||

            record.namaPerusahaan ||

            record.perusahaan ||

            record.kegiatan ||

            record.nomorSurat ||

            record.nomor ||

            "Data"

        );

    }


    /* =====================================================
       RENDER CARD
    ===================================================== */

    function renderRecord(
        page,
        record
    ) {

        const cfg =
            CONFIG[page];


        let details =
            "";


        cfg.fields.forEach(
            function(field) {

                const name =
                    field[0];

                const label =
                    field[1];

                const type =
                    field[2];


                if (
                    type === "file"
                ) {

                    return;

                }


                if (
                    !record[name]
                ) {

                    return;

                }


                details += `

                    <div
                        class="sibaper-data-detail"
                    >

                        <span>
                            ${escapeHTML(label)}
                        </span>

                        <strong>
                            ${escapeHTML(
                                record[name]
                            )}
                        </strong>

                    </div>

                `;

            }
        );


        let media =
            "";


        if (
            page === "galeri-foto" &&
            record.file
        ) {

            media = `

                <img
                    class="sibaper-data-image"
                    src="${record.file}"
                    alt="${escapeHTML(
                        record.judul
                    )}"
                >

            `;

        }

        else if (
            page === "galeri-video" &&
            record.url
        ) {

            media = `

                <div
                    class="sibaper-video-box"
                >

                    <a
                        href="${escapeHTML(
                            record.url
                        )}"
                        target="_blank"
                        rel="noopener"
                    >

                        ▶ Buka Video

                    </a>

                </div>

            `;

        }

        else {

            media =
                getFileButton(
                    record
                );

        }


        return `

            <article
                class="sibaper-data-card"
            >

                ${media}


                <div
                    class="sibaper-data-card-body"
                >

                    <span
                        class="sibaper-data-tag"
                    >

                        ${escapeHTML(
                            page
                                .replace(
                                    /-/g,
                                    " "
                                )
                                .toUpperCase()
                        )}

                    </span>


                    <h3>

                        ${escapeHTML(
                            recordTitle(
                                page,
                                record
                            )
                        )}

                    </h3>


                    <div
                        class="sibaper-data-details"
                    >

                        ${details}

                    </div>


                    <div
                        class="sibaper-data-actions"
                    >

                        <button
                            type="button"
                            data-sibaper-edit="${escapeHTML(
                                record.id
                            )}"
                        >

                            Edit

                        </button>


                        <button
                            type="button"
                            data-sibaper-delete="${escapeHTML(
                                record.id
                            )}"
                        >

                            Hapus

                        </button>

                    </div>

                </div>

            </article>

        `;

    }


    /* =====================================================
       RENDER PAGE
    ===================================================== */

    function renderDataPage(
        page
    ) {

        const container =
            document.querySelector(
                `[data-content="${page}"]`
            );


        if (
            !container ||
            !CONFIG[page]
        ) {

            return;

        }


        const old =
            container.querySelector(
                ".sibaper-data-render"
            );


        if (old) {

            old.remove();

        }


        const data =
            read(page);


        const wrapper =
            document.createElement(
                "div"
            );


        wrapper.className =
            "sibaper-data-render";


        if (
            data.length === 0
        ) {

            wrapper.innerHTML = `

                <div
                    class="sibaper-data-empty"
                >

                    <div>
                        📂
                    </div>

                    <h3>
                        Belum ada data
                    </h3>

                    <p>
                        Klik tombol tambah di atas
                        untuk memasukkan data.
                    </p>

                </div>

            `;

        }

        else {

            wrapper.innerHTML = `

                <div
                    class="sibaper-data-summary"
                >

                    <strong>
                        ${data.length}
                    </strong>

                    <span>
                        data tersimpan
                    </span>

                </div>


                <div
                    class="sibaper-data-grid"
                >

                    ${data
                        .map(
                            function(record) {

                                return renderRecord(
                                    page,
                                    record
                                );

                            }
                        )
                        .join("")}

                </div>

            `;

        }


        container.appendChild(
            wrapper
        );


        const oldEmpty =
            container.querySelector(
                ".empty-content"
            );


        if (oldEmpty) {

            oldEmpty.style.display =
                "none";

        }

    }


    /* =====================================================
       RENDER SEMUA
    ===================================================== */

    function renderAllData() {

        Object
            .keys(CONFIG)
            .forEach(
                function(page) {

                    renderDataPage(
                        page
                    );

                }
            );

    }


    /* =====================================================
       BUTTON TAMBAH / EDIT / HAPUS
    ===================================================== */

    function bindDataButtons() {

        document.addEventListener(
            "click",
            function(event) {


                /* TAMBAH */

                const addButton =
                    event.target.closest(
                        ".primary-action"
                    );


                if (addButton) {

                    const page =
                        addButton
                            .closest(
                                ".sibaper-page"
                            )
                            ?.dataset
                            .content;


                    if (
                        page &&
                        CONFIG[page]
                    ) {

                        event.preventDefault();


                        openDataModal(
                            page,
                            ""
                        );


                        return;

                    }

                }


                /* EDIT */

                const editButton =
                    event.target.closest(
                        "[data-sibaper-edit]"
                    );


                if (editButton) {

                    const page =
                        editButton
                            .closest(
                                ".sibaper-page"
                            )
                            ?.dataset
                            .content;


                    if (page) {

                        openDataModal(
                            page,
                            editButton
                                .dataset
                                .sibaperEdit
                        );

                    }


                    return;

                }


                /* HAPUS */

                const deleteButton =
                    event.target.closest(
                        "[data-sibaper-delete]"
                    );


                if (deleteButton) {

                    const page =
                        deleteButton
                            .closest(
                                ".sibaper-page"
                            )
                            ?.dataset
                            .content;


                    if (!page) {
                        return;
                    }


                    const data =
                        read(page);


                    const item =
                        data.find(
                            function(record) {

                                return (
                                    record.id ===
                                    deleteButton
                                        .dataset
                                        .sibaperDelete
                                );

                            }
                        );


                    if (!item) {
                        return;
                    }


                    if (
                        !confirm(
                            `Hapus "${recordTitle(
                                page,
                                item
                            )}"?`
                        )
                    ) {

                        return;

                    }


                    write(
                        page,
                        data.filter(
                            function(record) {

                                return (
                                    record.id !==
                                    item.id
                                );

                            }
                        )
                    );


                    renderDataPage(
                        page
                    );


                    alert(
                        "Data berhasil dihapus."
                    );

                }

            }
        );

    }


    /* =====================================================
       INITIALIZE DATA
    ===================================================== */

    function initializeDataModule() {

        buildModal();

        bindDataButtons();

        renderAllData();


        document.addEventListener(
            "sibaperPageChanged",
            function(event) {

                const page =
                    event.detail?.page;


                if (
                    CONFIG[page]
                ) {

                    renderDataPage(
                        page
                    );

                }

            }
        );


        console.log(
            "SIBAPER Data Module berhasil dijalankan."
        );

    }


    if (
        document.readyState === "loading"
    ) {

        document.addEventListener(
            "DOMContentLoaded",
            initializeDataModule
        );

    }

    else {

        initializeDataModule();

    }

})();


/* =========================================================
   START APPLICATION
========================================================= */

if (
    document.readyState === "loading"
) {

    document.addEventListener(
        "DOMContentLoaded",
        initializeSibaperApp
    );

}

else {

    initializeSibaperApp();

}