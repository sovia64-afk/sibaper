/* =========================================================
   SIBAPER - MODUL KINERJA
   Evaluasi + Penilaian + Rekap Kinerja
========================================================= */

(function () {

    "use strict";


    /* =====================================================
       STORAGE
    ===================================================== */

    const PROFILE_STORAGE =
        "sibaper_profil_data";

    const EVALUATION_STORAGE =
        "sibaper_evaluasi_data";

    const ASSESSMENT_STORAGE =
        "sibaper_penilaian_data";


    /* =====================================================
       UTILITY
    ===================================================== */

    function getProfiles() {

        try {

            const data =
                localStorage.getItem(
                    PROFILE_STORAGE
                );

            if (!data) {
                return [];
            }

            const parsed =
                JSON.parse(data);

            return Array.isArray(parsed)
                ? parsed
                : [];

        } catch (error) {

            console.error(
                "Gagal membaca data profil:",
                error
            );

            return [];

        }

    }


    function getStorage(key) {

        try {

            const data =
                localStorage.getItem(key);

            if (!data) {
                return [];
            }

            const parsed =
                JSON.parse(data);

            return Array.isArray(parsed)
                ? parsed
                : [];

        } catch (error) {

            console.error(
                "Gagal membaca data kinerja:",
                error
            );

            return [];

        }

    }


    function saveStorage(key, data) {

        try {

            localStorage.setItem(
                key,
                JSON.stringify(data)
            );

            return true;

        } catch (error) {

            console.error(
                "Gagal menyimpan data:",
                error
            );

            alert(
                "Data tidak dapat disimpan."
            );

            return false;

        }

    }


    function escapeHTML(value) {

        if (
            value === null ||
            value === undefined
        ) {

            return "";

        }

        return String(value)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");

    }


    function generateId() {

        return (
            Date.now().toString(36) +
            Math.random()
                .toString(36)
                .substring(2, 8)
        );

    }


    /* =====================================================
       FOTO
    ===================================================== */

    function getPhoto(profile) {

        if (profile.foto) {

            return `
                <img
                    src="${profile.foto}"
                    alt="${escapeHTML(profile.nama)}"
                    class="kinerja-profile-photo"
                >
            `;

        }

        return `
            <div class="kinerja-profile-placeholder">
                👤
            </div>
        `;

    }


    /* =====================================================
       CEK DATA
    ===================================================== */

    function getLatestRecord(
        profileId,
        type
    ) {

        const storageKey =
            type === "evaluasi"
                ? EVALUATION_STORAGE
                : ASSESSMENT_STORAGE;


        const records =
            getStorage(storageKey).filter(
                function (item) {

                    return (
                        item.profileId ===
                        profileId
                    );

                }
            );


        if (records.length === 0) {
            return null;
        }


        return records[
            records.length - 1
        ];

    }


    /* =====================================================
       RENDER UTAMA
    ===================================================== */

    function renderKinerja() {

        renderPage(
            "kinerja-evaluasi",
            "evaluasi"
        );


        renderPage(
            "kinerja-penilaian",
            "penilaian"
        );

    }


    /* =====================================================
       RENDER PAGE
    ===================================================== */

    function renderPage(
        pageId,
        type
    ) {

        const page =
            document.querySelector(
                `[data-content="${pageId}"]`
            );


        if (!page) {

            console.warn(
                "Halaman Kinerja tidak ditemukan:",
                pageId
            );

            return;

        }


        const profiles =
            getProfiles();


        /* -------------------------------------------------
           Hapus konten lama
        ------------------------------------------------- */

        const oldEmpty =
            page.querySelector(
                ".empty-content"
            );


        if (oldEmpty) {
            oldEmpty.remove();
        }


        const oldContainer =
            page.querySelector(
                ".kinerja-container"
            );


        if (oldContainer) {
            oldContainer.remove();
        }


        /* -------------------------------------------------
           CONTAINER
        ------------------------------------------------- */

        const container =
            document.createElement("div");


        container.className =
            "kinerja-container";


        /* -------------------------------------------------
           DATA REKAP
        ------------------------------------------------- */

        let completed = 0;


        profiles.forEach(
            function (profile) {

                const record =
                    getLatestRecord(
                        profile.id,
                        type
                    );


                if (record) {
                    completed++;
                }

            }
        );


        const pending =
            profiles.length -
            completed;


        /* -------------------------------------------------
           REKAP
        ------------------------------------------------- */

        const summary =
            document.createElement("div");


        summary.className =
            "kinerja-summary";


        summary.innerHTML = `

            <div class="kinerja-summary-card">

                <span>
                    TOTAL PEGAWAI
                </span>

                <strong>
                    ${profiles.length}
                </strong>

                <small>
                    Pegawai
                </small>

            </div>


            <div class="kinerja-summary-card success">

                <span>
                    SUDAH ${
                        type === "evaluasi"
                            ? "DIEVALUASI"
                            : "DINILAI"
                    }
                </span>

                <strong>
                    ${completed}
                </strong>

                <small>
                    Pegawai
                </small>

            </div>


            <div class="kinerja-summary-card pending">

                <span>
                    BELUM ${
                        type === "evaluasi"
                            ? "DIEVALUASI"
                            : "DINILAI"
                    }
                </span>

                <strong>
                    ${pending}
                </strong>

                <small>
                    Pegawai
                </small>

            </div>

        `;


        container.appendChild(
            summary
        );


        /* -------------------------------------------------
           HEADER
        ------------------------------------------------- */

        const header =
            document.createElement("div");


        header.className =
            "kinerja-section-header";


        header.innerHTML = `

            <div>

                <span class="kinerja-label">
                    KINERJA PEGAWAI
                </span>

                <h3>
                    ${
                        type === "evaluasi"
                            ? "Evaluasi Kinerja"
                            : "Penilaian Kinerja"
                    }
                </h3>

                <p>
                    ${
                        type === "evaluasi"
                            ? "Pilih pegawai untuk melakukan atau melihat evaluasi."
                            : "Pilih pegawai untuk melakukan atau melihat penilaian."
                    }
                </p>

            </div>

        `;


        container.appendChild(
            header
        );


        /* -------------------------------------------------
           BELUM ADA PROFIL
        ------------------------------------------------- */

        if (
            profiles.length === 0
        ) {

            const empty =
                document.createElement("div");


            empty.className =
                "kinerja-empty";


            empty.innerHTML = `

                <div class="kinerja-empty-icon">
                    👤
                </div>

                <h3>
                    Belum ada data pegawai
                </h3>

                <p>
                    Silakan masukkan data pegawai
                    melalui menu Profil terlebih dahulu.
                </p>

            `;


            container.appendChild(
                empty
            );


            page.appendChild(
                container
            );


            return;

        }


        /* -------------------------------------------------
           GRID
        ------------------------------------------------- */

        const grid =
            document.createElement("div");


        grid.className =
            "kinerja-profile-grid";


        profiles.forEach(
            function (profile) {

                const record =
                    getLatestRecord(
                        profile.id,
                        type
                    );


                const card =
                    document.createElement(
                        "button"
                    );


                card.type =
                    "button";


                card.className =
                    "kinerja-profile-card";


                card.dataset.profileId =
                    profile.id;


                card.dataset.kinerjaType =
                    type;


                /* -------------------------------------------------
                   STATUS
                ------------------------------------------------- */

                let statusHTML = "";


                if (record) {

                    statusHTML = `

                        <div class="kinerja-result-box">

                            <div class="kinerja-result-status">

                                ✓
                                ${
                                    type === "evaluasi"
                                        ? "Evaluasi sudah diisi"
                                        : "Penilaian sudah diisi"
                                }

                            </div>


                            <div class="kinerja-result-period">

                                Periode:

                                <strong>
                                    ${escapeHTML(
                                        record.periode
                                    )}
                                </strong>

                            </div>


                            <div class="kinerja-result-text">

                                ${escapeHTML(
                                    record.hasil
                                )}

                            </div>


                            ${
                                record.catatan
                                    ? `

                                        <div class="kinerja-result-note">

                                            <strong>
                                                Catatan:
                                            </strong>

                                            ${escapeHTML(
                                                record.catatan
                                            )}

                                        </div>

                                    `
                                    : ""
                            }

                        </div>

                    `;

                } else {

                    statusHTML = `

                        <div class="kinerja-result-empty">

                            Belum ada
                            ${
                                type === "evaluasi"
                                    ? "evaluasi"
                                    : "penilaian"
                            }

                        </div>

                    `;

                }


                /* -------------------------------------------------
                   CARD
                ------------------------------------------------- */

                card.innerHTML = `

                    <div class="kinerja-photo-wrapper">

                        ${getPhoto(profile)}

                    </div>


                    <div class="kinerja-profile-info">

                        <span class="kinerja-position">

                            ${escapeHTML(
                                profile.jabatan ||
                                "-"
                            )}

                        </span>


                        <h3>

                            ${escapeHTML(
                                profile.nama ||
                                "-"
                            )}

                        </h3>


                        <div class="kinerja-nip">

                            NIP:
                            ${escapeHTML(
                                profile.nip ||
                                "-"
                            )}

                        </div>


                        ${statusHTML}


                        <div class="kinerja-action-text">

                            ${
                                record
                                    ? "Klik untuk melihat / mengubah →"
                                    : type === "evaluasi"
                                        ? "Klik untuk melakukan evaluasi →"
                                        : "Klik untuk melakukan penilaian →"
                            }

                        </div>

                    </div>

                `;


                grid.appendChild(
                    card
                );

            }
        );


        container.appendChild(
            grid
        );


        page.appendChild(
            container
        );

    }


    /* =====================================================
       MODAL
    ===================================================== */

    function createModal() {

        if (
            document.getElementById(
                "kinerjaModal"
            )
        ) {

            return;

        }


        const modal =
            document.createElement(
                "div"
            );


        modal.id =
            "kinerjaModal";


        modal.className =
            "kinerja-modal-overlay";


        modal.innerHTML = `

            <div class="kinerja-modal">

                <div class="kinerja-modal-header">

                    <div>

                        <span
                            id="kinerjaModalType"
                            class="kinerja-modal-label"
                        ></span>

                        <h2
                            id="kinerjaModalName"
                        ></h2>

                    </div>


                    <button
                        type="button"
                        id="kinerjaModalClose"
                        class="kinerja-modal-close"
                    >
                        ×
                    </button>

                </div>


                <form
                    id="kinerjaForm"
                    class="kinerja-form"
                >

                    <input
                        type="hidden"
                        id="kinerjaProfileId"
                    >


                    <input
                        type="hidden"
                        id="kinerjaType"
                    >


                    <div class="kinerja-form-group">

                        <label>
                            Periode
                        </label>

                        <input
                            type="text"
                            id="kinerjaPeriode"
                            placeholder="Contoh: Tahun 2026"
                            required
                        >

                    </div>


                    <div class="kinerja-form-group">

                        <label>
                            Hasil
                        </label>

                        <textarea
                            id="kinerjaHasil"
                            rows="6"
                            placeholder="Masukkan hasil evaluasi atau penilaian..."
                            required
                        ></textarea>

                    </div>


                    <div class="kinerja-form-group">

                        <label>
                            Catatan
                        </label>

                        <textarea
                            id="kinerjaCatatan"
                            rows="4"
                            placeholder="Tambahkan catatan jika diperlukan..."
                        ></textarea>

                    </div>


                    <div class="kinerja-modal-footer">

                        <button
                            type="button"
                            id="kinerjaModalCancel"
                            class="kinerja-cancel-button"
                        >
                            Batal
                        </button>


                        <button
                            type="submit"
                            class="kinerja-save-button"
                        >
                            Simpan
                        </button>

                    </div>

                </form>

            </div>

        `;


        document.body.appendChild(
            modal
        );


        bindModal();

    }


    /* =====================================================
       MODAL EVENTS
    ===================================================== */

    function bindModal() {

        const modal =
            document.getElementById(
                "kinerjaModal"
            );


        const closeButton =
            document.getElementById(
                "kinerjaModalClose"
            );


        const cancelButton =
            document.getElementById(
                "kinerjaModalCancel"
            );


        const form =
            document.getElementById(
                "kinerjaForm"
            );


        closeButton.addEventListener(
            "click",
            closeModal
        );


        cancelButton.addEventListener(
            "click",
            closeModal
        );


        modal.addEventListener(
            "click",
            function (event) {

                if (
                    event.target === modal
                ) {

                    closeModal();

                }

            }
        );


        form.addEventListener(
            "submit",
            saveKinerja
        );

    }


    /* =====================================================
       OPEN MODAL
    ===================================================== */

    function openModal(
        profileId,
        type
    ) {

        createModal();


        const profiles =
            getProfiles();


        const profile =
            profiles.find(
                function (item) {

                    return (
                        item.id ===
                        profileId
                    );

                }
            );


        if (!profile) {

            alert(
                "Data pegawai tidak ditemukan."
            );

            return;

        }


        const existing =
            getLatestRecord(
                profileId,
                type
            );


        const form =
            document.getElementById(
                "kinerjaForm"
            );


        form.reset();


        document.getElementById(
            "kinerjaProfileId"
        ).value =
            profileId;


        document.getElementById(
            "kinerjaType"
        ).value =
            type;


        document.getElementById(
            "kinerjaModalType"
        ).textContent =
            type === "evaluasi"
                ? "EVALUASI KINERJA"
                : "PENILAIAN KINERJA";


        document.getElementById(
            "kinerjaModalName"
        ).textContent =
            profile.nama;


        /* -------------------------------------------------
           ISI DATA LAMA
        ------------------------------------------------- */

        if (existing) {

            document.getElementById(
                "kinerjaPeriode"
            ).value =
                existing.periode ||
                "";


            document.getElementById(
                "kinerjaHasil"
            ).value =
                existing.hasil ||
                "";


            document.getElementById(
                "kinerjaCatatan"
            ).value =
                existing.catatan ||
                "";

        }


        document.getElementById(
            "kinerjaModal"
        ).classList.add(
            "show"
        );

    }


    /* =====================================================
       CLOSE MODAL
    ===================================================== */

    function closeModal() {

        const modal =
            document.getElementById(
                "kinerjaModal"
            );


        if (modal) {

            modal.classList.remove(
                "show"
            );

        }

    }


    /* =====================================================
       SAVE KINERJA
    ===================================================== */

    function saveKinerja(
        event
    ) {

        event.preventDefault();


        const profileId =
            document.getElementById(
                "kinerjaProfileId"
            ).value;


        const type =
            document.getElementById(
                "kinerjaType"
            ).value;


        const periode =
            document.getElementById(
                "kinerjaPeriode"
            ).value.trim();


        const hasil =
            document.getElementById(
                "kinerjaHasil"
            ).value.trim();


        const catatan =
            document.getElementById(
                "kinerjaCatatan"
            ).value.trim();


        if (
            !profileId ||
            !periode ||
            !hasil
        ) {

            alert(
                "Periode dan hasil wajib diisi."
            );

            return;

        }


        const storageKey =
            type === "evaluasi"
                ? EVALUATION_STORAGE
                : ASSESSMENT_STORAGE;


        const data =
            getStorage(
                storageKey
            );


        /* -------------------------------------------------
           CEK DATA LAMA
        ------------------------------------------------- */

        const existingIndex =
            data.findIndex(
                function (item) {

                    return (
                        item.profileId ===
                        profileId
                    );

                }
            );


        const record = {

            id:
                existingIndex >= 0
                    ? data[
                        existingIndex
                    ].id
                    : generateId(),

            profileId,

            periode,

            hasil,

            catatan,

            createdAt:
                existingIndex >= 0
                    ? data[
                        existingIndex
                    ].createdAt
                    : new Date()
                        .toISOString(),

            updatedAt:
                new Date()
                    .toISOString()

        };


        if (
            existingIndex >= 0
        ) {

            data[
                existingIndex
            ] = record;

        } else {

            data.push(
                record
            );

        }


        const saved =
            saveStorage(
                storageKey,
                data
            );


        if (!saved) {
            return;
        }


        closeModal();


        renderKinerja();


        alert(
            type === "evaluasi"
                ? "Evaluasi berhasil disimpan."
                : "Penilaian berhasil disimpan."
        );

    }


    /* =====================================================
       CLICK CARD
    ===================================================== */

    document.addEventListener(
        "click",
        function (event) {

            const card =
                event.target.closest(
                    ".kinerja-profile-card"
                );


            if (!card) {
                return;
            }


            openModal(
                card.dataset.profileId,
                card.dataset.kinerjaType
            );

        }
    );


    /* =====================================================
       PAGE CHANGED
    ===================================================== */

    document.addEventListener(
        "sibaperPageChanged",
        function (event) {

            if (
                !event.detail
            ) {

                return;

            }


            const page =
                event.detail.page;


            if (
                page ===
                    "kinerja-evaluasi" ||
                page ===
                    "kinerja-penilaian"
            ) {

                setTimeout(
                    function () {

                        renderKinerja();

                    },
                    0
                );

            }

        }
    );


    /* =====================================================
       INITIALIZATION
    ===================================================== */

    function initialize() {

        createModal();


        renderKinerja();


        console.log(
            "SIBAPER Kinerja berhasil dijalankan."
        );

    }


    if (
        document.readyState ===
        "loading"
    ) {

        document.addEventListener(
            "DOMContentLoaded",
            initialize
        );

    } else {

        initialize();

    }


})();