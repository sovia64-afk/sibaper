document.getElementById("loginForm").addEventListener("submit", function (event) {
    event.preventDefault();

    alert("Form login berhasil dibuat. Sistem login akan kita hubungkan ke Google Sheets nanti.");
});